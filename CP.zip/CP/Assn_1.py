from pathlib import Path
from glob import glob
def GetPathNames(rootPath):
    rootdir=Path(rootPath)
    print"All Subdirectories Names:"
    for directory in rootdir.resolve().glob('**/*'):
        if directory.is_dir():
           print directory
    print"**************************"        

    print"All FileNames Within A  Directory And Subdirectory :"    
    for filename in rootdir.resolve().glob('**/*'):
        if filename.is_file():
           print(filename)
    print"**************************" 

def main():
    rootPath = raw_input("Enter Path Name: ")
    GetPathNames(rootPath)

main()
