##from pathlib import Path
##rootdir = Path('C:/Users/REEMA BARUAH/Desktop/Folder')
##file_list = [f for f in rootdir.glob('**/*') if f.is_file()]
##print dir
###file_list = [f for f in rootdir.resolve().glob('**/*') if f.is_file()]
##for f in file_list:
##   print(f)


##import os
##
##rootdir = 'C:/Users/REEMA BARUAH/Desktop/Folder'
##[ os.path.join(rootdir, o) for o in os.listdir(rootdir) 
##                    if os.path.isdir(os.path.join(rootdir,o))]

from pathlib import Path
from glob import glob
#rootPath = raw_input("Enter Path Name: ")
#print rootPath
#rootPath="C:/Users/REEMA BARUAH/Desktop/Folder"
##rootdir=Path("C:/Users/REEMA BARUAH/Desktop/Folder")
#rootdir=Path(rootPath)
##l=rootPath.split('/')
##print "Current Directory:",l[-1]
##for f in rootdir.glob('**/*'):
##    if f.is_dir():
##        f=str(f)
##        if '//' in f:
##            l= f.split('//')
##            print "Sub Directory:",l[-1]
##            
##        elif '\\' in f:
##            l= f.split('\\')
##            print "Sub Directory:",l[-1]
##        elif '/' in f:
##            l= f.split('/')
##            print "Sub Directory:",l[-1]

   
##file_list = [f for f in rootdir.resolve().glob('**/*') if f.is_dir()]
##for f in file_list:
##    print(f)       
##file_list = [f for f in rootdir.resolve().glob('**/*') if f.is_file()]
##for f in file_list:
##    print(f)

##A = set(["CP","Waris","Gaurav","Nur"])
##B = set(["Waris","Danish","Bhumika"])
##CommonNames = A&B
##for Name in CommonNames:
##   #print(CommonNames)
##   print(Name)
##NamesA=A-B
##for Name in NamesA:
##   #print(CommonNames)
##   print(Name)

A = set(["CP","Waris","Afzalur","Gaurav","Nur"])
B = set(["Waris","Danish","Afzalur","Bhumika","Gaurav"])
print "Common Elements In A And B:",
for element in A:
    if element in B:
        print element,",",
        
print "\nElements In A But Not In B:",
for element in A:
    if element not in B:
        print element,",",
#print glob("/")
