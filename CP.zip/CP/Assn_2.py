def IterativeMethod():
    A = set(["CP","Waris","Afzalur","Gaurav","Nur"])
    B = set(["Waris","Danish","Afzalur","Bhumika","Gaurav"])
    print "\nCommon Elements In A And B:",
    for element in A:
        if element in B:
            print element,",",
            
    print "\nElements In A But Not In B:",
    for element in A:
        if element not in B:
            print element,",",
            
def BitOperatorMethod():
    A = set(["CP","Waris","Afzalur","Gaurav","Nur"])
    B = set(["Waris","Danish","Afzalur","Bhumika","Gaurav"])
    CommonNames = A&B
    print "\nCommon Elements In A And B:",
    for Name in CommonNames:
        print(Name),",",
    NamesA=A-B
    print "\nElements In A But Not In B:",
    for Name in NamesA:
        print(Name),",",
def main():
    IterativeMethod()
    BitOperatorMethod()

main()
